﻿using Microsoft.AspNetCore.SignalR;
using SignalRDemo.App_start;
using SignalRDemo.Interface;
using System;
using System.Threading.Tasks;

namespace SignalRDemo.Hubs
{
    public class NotificationHub : Hub
    {
        

    }
}
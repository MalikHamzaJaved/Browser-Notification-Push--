﻿using Microsoft.AspNetCore.SignalR;
using System;
using SignalRDemo.Interface;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using SignalRDemo.App_start;

namespace SignalRDemo.Hubs
{
    public class NotificationUserHub : Hub
    {
        //This is not for use Sara kam notificationHub k andar horha hai



        private readonly IUserConnectionManager _userConnectionManager;
        public NotificationUserHub(IUserConnectionManager userConnectionManager)
        {
            _userConnectionManager = userConnectionManager;
        }
        public string GetConnectionId()
        {
            var httpContext = this.Context.GetHttpContext();
            var userId = httpContext.Request.Query["userId"];
            _userConnectionManager.KeepUserConnection(userId, Context.ConnectionId);

            return Context.ConnectionId;
        }

      
        public async override Task OnDisconnectedAsync(Exception exception)
        {
            
            var connectionId = Context.ConnectionId;
            _userConnectionManager.RemoveUserConnection(connectionId);
            var value = await Task.FromResult(0);
        }
        public async override Task OnConnectedAsync()
        {

            var httpContext = this.Context.GetHttpContext();
            var userId = httpContext.Request.Query["userId"];

            _userConnectionManager.KeepUserConnection(userId, Context.ConnectionId);
             var value = await Task.FromResult(0);
          
        }
       
        
    }
}

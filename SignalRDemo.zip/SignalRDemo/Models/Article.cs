﻿namespace SignalRDemo.Models
{
    public class Article
    {
        public string articleHeading { get; set; }
        public string articleContent { get; set; }
        public string userId { get; set; }
    }
}
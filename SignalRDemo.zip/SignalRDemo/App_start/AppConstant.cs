﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRDemo.App_start
{
    public class AppConstant
    {
        public static readonly string UserOneId = "1";
        public static readonly string UserTwoId = "2";
        public static readonly string UserThreeId = "3";
        public static readonly string UserFourId = "4";


    }
}

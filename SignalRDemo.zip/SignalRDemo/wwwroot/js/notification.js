﻿"use strict";
var connection = new signalR.HubConnectionBuilder().withUrl("/NotificationHub").build();
connection.on("sendToUser", (articleHeading, articleContent) => {


    if (window.Notification && Notification.permission !== "denied") {
        Notification.requestPermission(function (status) {  // status is "granted", if accepted by user
            var n = new Notification('Title', {
                body: articleHeading,
                icon: '/path/to/icon.png' // You can put a picture here from the sender may woh ap k ouper hai
            });
        });
    }
    //var heading = document.createElement("h3");
    //heading.textContent = articleHeading;

    //var p = document.createElement("p");
    //p.innerText = articleContent;

    //var div = document.createElement("div");
    //div.appendChild(heading);
    //div.appendChild(p);

    //document.getElementById("articleList").appendChild(div);
});
connection.start().catch(function (err) {
    return console.error(err.toString());
});